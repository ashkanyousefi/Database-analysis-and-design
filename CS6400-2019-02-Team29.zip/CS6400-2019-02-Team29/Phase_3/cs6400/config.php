<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "cs6400_su19_team029";
$conn = new mysqli($servername, $username, $password,$database);
?>
