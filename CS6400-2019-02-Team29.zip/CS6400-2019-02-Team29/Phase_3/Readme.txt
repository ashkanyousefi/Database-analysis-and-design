A form desgin is added using the https://balsamiq.com/wireframes/desktop/
There is a possibility to convert the design to the PhP as well.
The Balsamiq project file and the relevant Png files are uploaded into the folder.
